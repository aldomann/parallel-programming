#!/bin/bash
perfbin=do-perf.sh

chmod +x $perfbin

source=$1
executable=run
perfoutfile=$2

if [ -f ${perfoutfile}-base.csv ]; then
	rm ${perfoutfile}-base.csv
	echo "Removed previous results."
fi

for (( i = 25; i <= 125; i +=25 )); do
	gcc -lm -O3 ${source}-base.c -o $executable
	bash $perfbin $i $i $i $executable ${perfoutfile}-base.csv
done

if [ -f ${perfoutfile}-notime.csv ]; then
	rm ${perfoutfile}-notime.csv
	echo "Removed previous results."
fi

for (( i = 25; i <= 125; i +=25 )); do
	gcc -lm -O3 ${source}-notime.c -o $executable
	bash $perfbin $i $i $i $executable ${perfoutfile}-notime.csv
done

if [ -f ${perfoutfile}-notime-goodloop.csv ]; then
	rm ${perfoutfile}-notime-goodloop.csv
	echo "Removed previous results."
fi

for (( i = 25; i <= 125; i +=25 )); do
	gcc -lm -O3 ${source}-notime-goodloop.c -o $executable
	bash $perfbin $i $i $i $executable ${perfoutfile}-notime-goodloop.csv
done
