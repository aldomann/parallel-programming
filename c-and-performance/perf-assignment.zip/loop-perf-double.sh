#!/bin/bash
perfbin=do-perf.sh

chmod +x $perfbin

source=$1
executable=run
perfoutfile=$2

if [ -f ${perfoutfile}-double.csv ]; then
	rm ${perfoutfile}-double.csv
	echo "Removed previous results."
fi

for (( i = 25; i <= 125; i +=25 )); do
	gcc -lm ${source}.c -o $executable
	bash $perfbin $i $i $i $executable ${perfoutfile}-double.csv
done
