#!/bin/bash
perfbin=do-perf.sh

chmod +x $perfbin

source=$1
executable=run
perfoutfile=$2

if [ -f ${perfoutfile}-no.csv ]; then
	rm ${perfoutfile}-no.csv
	echo "Removed previous results."
fi

for (( i = 25; i <= 125; i +=25 )); do
	gcc -lm ${source}.c -o $executable
	bash $perfbin $i $i $i $executable ${perfoutfile}-no.csv
done

if [ -f ${perfoutfile}-o2.csv ]; then
	rm ${perfoutfile}-o2.csv
	echo "Removed previous results."
fi

for (( i = 25; i <= 125; i +=25 )); do
	gcc -lm -O2 ${source}.c -o $executable
	bash $perfbin $i $i $i $executable ${perfoutfile}-o2.csv
done

if [ -f ${perfoutfile}-o3.csv ]; then
	rm ${perfoutfile}-o3.csv
	echo "Removed previous results."
fi

for (( i = 25; i <= 125; i +=25 )); do
	gcc -lm -O3 ${source}.c -o $executable
	bash $perfbin $i $i $i $executable ${perfoutfile}-o3.csv
done
